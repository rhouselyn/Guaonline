import { motion, AnimatePresence } from 'framer-motion'
import { ArrowLeft, Loader2, CheckCircle2, ChevronRight, Brain, BookOpen, Volume2, Languages } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { speakText } from '../utils/speech'
import { useMediaQuery } from '../utils/useMediaQuery'

function LearningStep({ learningData, showWordCard, selectedOption, isCorrect, onOptionSelect, onNextWord, onBack, onOpenVocabList, loading, t, sourceLang, skipListening, reviewMode, reviewIndex, wrongItemsCount }) {
  const speakTimerRef = useRef(null)
  const isDesktop = useMediaQuery('(min-width: 768px)')
  // 学习模式由父组件 showWordCard 控制：0=题目，1=单词卡（答对后自动切换）
  const activeMode = showWordCard ? 1 : 0

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [learningData?.word])

  useEffect(() => {
    if (speakTimerRef.current) {
      clearTimeout(speakTimerRef.current)
      speakTimerRef.current = null
    }
    if (learningData?.word && !skipListening) {
      speakTimerRef.current = setTimeout(() => {
        speakText(learningData.word, sourceLang)
        speakTimerRef.current = null
      }, 300)
    }
    return () => {
      if (speakTimerRef.current) {
        clearTimeout(speakTimerRef.current)
        speakTimerRef.current = null
      }
    }
  }, [learningData?.word, sourceLang, skipListening])

  if (!learningData) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto"
      >
        <div className="text-center py-16">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-ink-400" />
          <p className="text-lg text-ink-600">{t.loading}</p>
        </div>
      </motion.div>
    )
  }

  const stepInUnit = reviewMode ? (reviewIndex + 1) : ((learningData.step_in_unit ?? 0) + 1)
  const listeningCountInUnit = learningData.listening_count_in_unit ?? 0
  const rawTotalItemsInUnit = learningData.total_items_in_unit ?? learningData.word_count_in_unit ?? learningData.unit_end_index ?? 0
  const totalItemsInUnit = reviewMode ? (wrongItemsCount ?? 0) : (skipListening ? rawTotalItemsInUnit - listeningCountInUnit : rawTotalItemsInUnit)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-3xl mx-auto"
    >
      <div className="flex items-center gap-1 sm:gap-2 mb-5 sm:mb-8">
        <div className="flex items-center gap-1 sm:gap-2 min-w-0 shrink-0">
          <motion.button
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            onClick={onBack}
            className="flex items-center gap-1 sm:gap-2 btn-ghost px-2 py-1 sm:px-3 sm:py-2 text-xs sm:text-sm whitespace-nowrap"
          >
            <ArrowLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
            <span className="truncate">{t.back}</span>
          </motion.button>
        </div>
        <div className="flex-1 flex items-center justify-start min-w-0">
          {totalItemsInUnit > 0 && (
            <span className="text-xs sm:text-sm text-ink-500 font-medium whitespace-nowrap tabular-nums">
              {(t.stepProgress || '第 {0} / {1} 题').replace('{0}', stepInUnit).replace('{1}', totalItemsInUnit)}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5 sm:gap-3 min-w-0 shrink-0">
          {onOpenVocabList && (
            <motion.button
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={onOpenVocabList}
              className="flex items-center gap-1 sm:gap-2 btn-ghost px-2 py-1 sm:px-3 sm:py-2 text-xs sm:text-sm whitespace-nowrap"
            >
              <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
              <span className="truncate">{t.vocabList || '单词表'}</span>
            </motion.button>
          )}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeMode === 0 ? (
          <motion.div
            key="question"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-parchment-50 border-2 border-aged-200 rounded-md p-5 sm:p-8 shadow-retro-sm"
          >
            <div className="text-center mb-8">
              <div className="flex items-center justify-center gap-3 mb-2">
                <motion.h2
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-3xl sm:text-4xl font-bold font-display text-ink-700"
                >
                  {learningData.word}
                </motion.h2>
                <motion.button
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={(e) => { e.stopPropagation(); speakText(learningData.word, sourceLang) }}
                  className="p-2 text-amber-500 hover:text-amber-500 hover:bg-amber-50 rounded-none transition-colors"
                >
                  <Volume2 className="w-6 h-6" />
                </motion.button>
              </div>
              {learningData.ipa && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  className="text-xl text-ink-400 ipa-font"
                >
                  {learningData.ipa.startsWith('/') ? learningData.ipa : `/${learningData.ipa}/`}
                </motion.p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {learningData.options.map((option, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onOptionSelect(index)}
                  disabled={selectedOption !== null && isCorrect}
                  className={`w-full py-3 px-4 text-left rounded-sm transition-all ${selectedOption === index ? (isCorrect ? 'bg-olive-50 border-2 border-olive-400 text-olive-500' : 'bg-rust-50 border-2 border-rust-400 text-rust-400') : 'border-2 border-aged-200 bg-parchment-50 text-ink-800 hover:border-amber-300'}`}
                >
                  <div className="flex items-center gap-3">
                    {selectedOption === index && isCorrect && (
                      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="w-5 h-5 rounded-none flex items-center justify-center">
                        <CheckCircle2 className="w-4 h-4 text-olive-600" />
                      </motion.div>
                    )}
                    <span className="text-lg">{option}</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="word-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-parchment-50 border-2 border-aged-200 rounded-md p-5 sm:p-8 shadow-retro-sm"
          >
            <div className="flex items-start justify-between mb-8">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <motion.h2
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-3xl sm:text-4xl font-bold font-display text-ink-700"
                  >
                    {learningData.word}
                  </motion.h2>
                  <motion.button
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    whileHover={{ scale: 1.15 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => { e.stopPropagation(); speakText(learningData.word, sourceLang) }}
                    className="p-2 text-amber-500 hover:text-amber-500 hover:bg-amber-50 rounded-none transition-colors"
                  >
                    <Volume2 className="w-6 h-6" />
                  </motion.button>
                </div>
                {learningData.ipa && (
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="text-xl text-ink-400 ipa-font"
                  >
                    {learningData.ipa.startsWith('/') ? learningData.ipa : `/${learningData.ipa}/`}
                  </motion.p>
                )}
              </div>
            </div>

            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
              >
                <h3 className="text-sm font-bold text-ink-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Brain className="w-4 h-4" />
                  {t.definition}
                </h3>
                <p className="text-lg text-ink-600 leading-relaxed">
                  {learningData.enriched_meaning || learningData.correct_meaning}
                </p>
              </motion.div>

              {learningData.context && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <h3 className="text-sm font-bold text-ink-400 uppercase tracking-wider mb-3">
                    {t.context}
                  </h3>
                  <div className="flex items-start gap-2">
                    <p className="text-lg text-ink-600 leading-relaxed italic flex-1">
                      {learningData.context}
                    </p>
                    <motion.button
                      whileHover={{ scale: 1.15 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={(e) => { e.stopPropagation(); speakText(learningData.context, sourceLang) }}
                      className="p-1.5 text-amber-500 hover:text-amber-500 hover:bg-amber-50 rounded-none transition-colors shrink-0 mt-1"
                    >
                      <Volume2 className="w-4 h-4" />
                    </motion.button>
                  </div>
                </motion.div>
              )}

              {(learningData.meaning || learningData.context_meaning) && (learningData.meaning || learningData.context_meaning) !== learningData.enriched_meaning && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 }}
                  className="bg-amber-50 p-4 rounded-sm border-2 border-amber-200"
                >
                  <h4 className="text-sm font-medium text-amber-500 mb-2">{t.contextMeaning || '上下文释义'}</h4>
                  <p className="text-ink-600">{learningData.meaning || learningData.context_meaning}</p>
                </motion.div>
              )}

              {learningData.variants_detail && learningData.variants_detail.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 }}
                >
                  <h3 className="text-sm font-bold text-ink-400 uppercase tracking-wider mb-3">
                    {t.variants}
                  </h3>
                  <div className="space-y-2">
                    {learningData.variants_detail.map((variant, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <span className="px-2 py-1 bg-parchment-100 text-ink-700 rounded text-sm font-medium">
                          {variant.type}
                        </span>
                        <span className="text-ink-700">{variant.form}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {learningData.examples && learningData.examples.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <h3 className="text-sm font-bold text-ink-400 uppercase tracking-wider mb-3">
                    {t.examples}
                  </h3>
                  <div className="space-y-4">
                    {learningData.examples.map((example, index) => (
                      <div key={index} className="border-l-4 border-aged-300 pl-4">
                        <div className="flex items-start gap-2">
                          <p className="text-ink-800 mb-1 flex-1">{example.sentence}</p>
                          <motion.button
                            whileHover={{ scale: 1.15 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={(e) => { e.stopPropagation(); speakText(example.sentence, sourceLang) }}
                            className="p-1 text-amber-500 hover:text-amber-500 hover:bg-amber-50 rounded-none transition-colors shrink-0"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </motion.button>
                        </div>
                        <p className="text-ink-600 text-sm">{example.translation}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {learningData.memory_hint && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.35 }}
                >
                  <h3 className="text-sm font-bold text-ink-400 uppercase tracking-wider mb-3">
                    {t.memoryHint}
                  </h3>
                  <p className="text-lg text-ink-600 leading-relaxed bg-amber-50 p-4 rounded-sm border-2 border-amber-200">
                    {learningData.memory_hint}
                  </p>
                </motion.div>
              )}
            </div>

            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={onNextWord}
              disabled={loading}
              className="mt-8 w-full py-4 btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {t.loading}
                </>
              ) : (
                <>
                  {t.nextQuestion}
                  <ChevronRight className="w-5 h-5" />
                </>
              )}
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export default LearningStep
