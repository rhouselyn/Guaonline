// TTS 语音合成 - 支持 Edge TTS（后端 API）和 Web Speech API（浏览器原生）

const SPEECH_LANG_MAP = {
  'en': 'en-US',
  'fr': 'fr-FR',
  'pt': 'pt-BR',
  'de': 'de-DE',
  'ro': 'ro-RO',
  'sv': 'sv-SE',
  'da': 'da-DK',
  'bg': 'bg-BG',
  'ru': 'ru-RU',
  'cs': 'cs-CZ',
  'el': 'el-GR',
  'uk': 'uk-UA',
  'es': 'es-ES',
  'nl': 'nl-NL',
  'sk': 'sk-SK',
  'hr': 'hr-HR',
  'pl': 'pl-PL',
  'lt': 'lt-LT',
  'nb': 'nb-NO',
  'nn': 'nn-NO',
  'fa': 'fa-IR',
  'sl': 'sl-SI',
  'gu': 'gu-IN',
  'lv': 'lv-LV',
  'it': 'it-IT',
  'oc': 'oc-FR',
  'ne': 'ne-NP',
  'mr': 'mr-IN',
  'be': 'be-BY',
  'sr': 'sr-RS',
  'lb': 'lb-LU',
  'vec': 'it-IT',
  'as': 'as-IN',
  'cy': 'cy-GB',
  'szl': 'pl-PL',
  'ast': 'ast-ES',
  'hne': 'hi-IN',
  'awa': 'hi-IN',
  'mai': 'mai-IN',
  'bho': 'bho-IN',
  'sd': 'sd-PK',
  'ga': 'ga-IE',
  'fo': 'fo-FO',
  'hi': 'hi-IN',
  'pa': 'pa-IN',
  'bn': 'bn-IN',
  'or': 'or-IN',
  'tg': 'tg-TJ',
  'yi': 'yi-US',
  'lmo': 'it-IT',
  'lij': 'it-IT',
  'scn': 'it-IT',
  'fur': 'it-IT',
  'sc': 'sc-IT',
  'gl': 'gl-ES',
  'ca': 'ca-ES',
  'is': 'is-IS',
  'sq': 'sq-AL',
  'li': 'li-NL',
  'prs': 'fa-AF',
  'af': 'af-ZA',
  'mk': 'mk-MK',
  'si': 'si-LK',
  'ur': 'ur-PK',
  'mag': 'hi-IN',
  'bs': 'bs-BA',
  'hy': 'hy-AM',
  'zh': 'zh-CN',
  'zh-TW': 'zh-TW',
  'yue': 'yue-CN',
  'my': 'my-MM',
  'ar': 'ar-SA',
  'ars': 'ar-SA',
  'apc': 'ar-SY',
  'arz': 'ar-EG',
  'ary': 'ar-MA',
  'acm': 'ar-IQ',
  'acq': 'ar-YE',
  'aeb': 'ar-TN',
  'he': 'he-IL',
  'mt': 'mt-MT',
  'id': 'id-ID',
  'ms': 'ms-MY',
  'tl': 'tl-PH',
  'ceb': 'ceb-PH',
  'jv': 'jv-ID',
  'su': 'su-ID',
  'min': 'min-ID',
  'ban': 'ban-ID',
  'bjn': 'bjn-ID',
  'pag': 'pag-PH',
  'ilo': 'ilo-PH',
  'war': 'war-PH',
  'ta': 'ta-IN',
  'te': 'te-IN',
  'kn': 'kn-IN',
  'ml': 'ml-IN',
  'tr': 'tr-TR',
  'az': 'az-AZ',
  'uz': 'uz-UZ',
  'kk': 'kk-KZ',
  'ba': 'ba-RU',
  'tt': 'tt-RU',
  'th': 'th-TH',
  'lo': 'lo-LA',
  'fi': 'fi-FI',
  'et': 'et-EE',
  'hu': 'hu-HU',
  'vi': 'vi-VN',
  'km': 'km-KH',
  'ja': 'ja-JP',
  'ko': 'ko-KR',
  'ka': 'ka-GE',
  'eu': 'eu-ES',
  'ht': 'ht-HT',
  'pap': 'pap-AW',
  'kea': 'kea-CV',
  'tpi': 'tpi-PG',
  'sw': 'sw-KE',
}

// 当前播放的 Audio 对象
let currentAudio = null

// TTS 引擎选择：'edge'（默认）或 'webspeech'
const TTS_ENGINE_KEY = 'gualingo_tts_engine'
let ttsEngine = localStorage.getItem(TTS_ENGINE_KEY) || 'edge'

function setTtsEngine(engine) {
  ttsEngine = engine
  localStorage.setItem(TTS_ENGINE_KEY, engine)
}

function getTtsEngine() {
  return ttsEngine
}

function warmupSpeech() {
  // Edge TTS 不需要 warmup；Web Speech API 可预热
  if (ttsEngine === 'webspeech' && 'speechSynthesis' in window) {
    window.speechSynthesis.getVoices()
  }
}

// Web Speech API 发音
function speakWithWebSpeech(text, lang, slow) {
  if (!('speechSynthesis' in window)) {
    console.warn('Web Speech API not available')
    return
  }

  // 停止当前播放
  window.speechSynthesis.cancel()

  // ponytail: 先检查是否有匹配该语种的 voice。Web Speech 传入不支持的 lang 会触发 error 事件，
  // 且部分浏览器会播放默认语种（发音错乱）。无匹配 voice 时直接静默返回，不生成语音。
  const voices = window.speechSynthesis.getVoices()
  const langPrefix = lang.split('-')[0].toLowerCase()
  const matchedVoice = voices.find(v => v.lang === lang)
    || voices.find(v => v.lang && v.lang.toLowerCase() === lang.toLowerCase())
    || voices.find(v => v.lang && v.lang.toLowerCase().startsWith(langPrefix))
  if (!matchedVoice) {
    console.warn(`[webspeech] 无匹配 voice for lang=${lang}，跳过语音生成（避免传入不支持的 lang 触发 error）`)
    return
  }

  const utterance = new SpeechSynthesisUtterance(text)
  utterance.lang = lang
  utterance.voice = matchedVoice
  utterance.rate = slow ? 0.6 : 1.0

  // 兜底：即使 voice 匹配，运行时仍可能因语种不支持触发 error（如 voices 异步加载未完成）。
  // 监听 error 静默处理，避免未捕获异常污染控制台。
  utterance.onerror = (e) => {
    console.warn(`[webspeech] utterance error: ${e.error || 'unknown'}, lang=${lang}`)
  }

  window.speechSynthesis.speak(utterance)
}

// Edge TTS 发音（通过后端 API 流式播放）
async function speakWithEdgeTts(text, lang, slow) {
  const url = `/api/tts/speak?text=${encodeURIComponent(text)}&lang=${encodeURIComponent(lang)}&slow=${slow}`

  // 使用 fetch 流式获取音频，边下载边播放
  const response = await fetch(url)
  if (!response.ok) throw new Error(`TTS request failed: ${response.status}`)

  const reader = response.body.getReader()

  // 使用 MediaSource 实现边下载边播放
  const mediaSource = new MediaSource()
  const audio = new Audio()
  audio.src = URL.createObjectURL(mediaSource)
  currentAudio = audio

  audio.onended = () => {
    if (currentAudio === audio) currentAudio = null
  }
  audio.onerror = () => {
    if (currentAudio === audio) currentAudio = null
  }

  await new Promise((resolve, reject) => {
    mediaSource.addEventListener('sourceopen', resolve, { once: true })
    mediaSource.addEventListener('error', reject, { once: true })
  })

  const sourceBuffer = mediaSource.addSourceBuffer('audio/mpeg')

  sourceBuffer.addEventListener('updateend', async () => {
    try {
      const { value, done } = await reader.read()
      if (done) {
        mediaSource.endOfStream()
        return
      }
      sourceBuffer.appendBuffer(value)
    } catch (e) {
      console.warn('Edge TTS stream read error:', e)
      try { mediaSource.endOfStream() } catch (_) {}
    }
  })

  // 读取第一个 chunk 并开始播放
  const { value, done } = await reader.read()
  if (done) {
    mediaSource.endOfStream()
    return
  }
  sourceBuffer.appendBuffer(value)

  await audio.play()
}

async function speakText(text, sourceLang = 'en', slow = false) {
  if (!text) return

  // 停止当前播放
  if (currentAudio) {
    currentAudio.pause()
    currentAudio = null
  }
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel()
  }

  const lang = SPEECH_LANG_MAP[sourceLang] || sourceLang

  try {
    if (ttsEngine === 'webspeech') {
      speakWithWebSpeech(text, lang, slow)
    } else {
      await speakWithEdgeTts(text, lang, slow)
    }
  } catch (e) {
    console.warn('TTS error:', e)
    currentAudio = null
  }
}

export { SPEECH_LANG_MAP as LANG_MAP, speakText, warmupSpeech, setTtsEngine, getTtsEngine }
